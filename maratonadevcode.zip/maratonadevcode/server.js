//configurando o servidor
const express = require("express")
const server = express()

//configurar o servidor para apresentar arquivos estáticos
server.use(express.static('public'))

//habilitar body do formulario
server.use(express.urlencoded({extended: true}))

//configurando a template engine
const nunjucks = require("nunjucks")
nunjucks.configure("./",{
    express: server,
    noCache: true,
})

//LISTA DE DOADORES
const donors =[
    {
        name:"Wendell Claus",
        blood:"B-"
    },
    {
        name:"Luke Skywalker",
        blood:"AB+"
    },
    {
        name:"Nicolas Leite",
        blood:"O+"
    },
    {
        name:"Francine C. Leite",
        blood:"B+"
    }
]



//configurar apresentação da página
server.get("/",function(req, res){
    return res.render("index.html",{donors})
})

server.post("/",function(req,res) {
    //pegar dados dop formulario
    const name = req.body.name
    const email = req.body.email
    const blood = req.body.blood

    //coloco valores no array
    donors.push({
        name:name,
        bloof:blood,
    })

    return res.redirect("/")

})


//ligar o servidore permitir o acesso a porta 3000
server.listen(3000,function(){
    console.log("iniciei o servidor")
})